<?php

namespace Database\Seeders;

use App\Models\PermissionToUser;
use Illuminate\Database\Seeder;

class PermissionToUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    }
}
