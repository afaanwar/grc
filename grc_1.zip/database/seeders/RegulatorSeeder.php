<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RegulatorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $regulators = [
        //     ['name' => 'NCA'],
        //     ['name' => 'ISO'],
        //     ['name' => 'SAMA'],
        //     ['name' => 'CMA'],
        // ];

        // DB::table('regulators')->insert($regulators);
    }
}
